package com.example.apk2rce;

import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.os.Bundle;
import android.text.Layout;
import android.text.SpannableString;
import android.text.style.AlignmentSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {
    private EditText inputEditText;
    private LinearLayout chatHistoryLayout;

    private final static byte[] EncryptedURL = new byte[]{26, 21, 29, 30, 88, 31, 88, 67, 25, 23, 19, 29, 64, 1, 95, 26, 30, 20, 28, 91, 88, 94, 83, 2, 88, 83, 24, 28, 15, 12, 13, 22, 31, 29, 84, 21, 17, 2, 6, 0, 12, 85, 20, 68, 72};

    public static String result = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputEditText = findViewById(R.id.inputEditText);
        chatHistoryLayout = findViewById(R.id.chatHistoryLayout);

        List<String> jokerMessgaes = new ArrayList<>();
        List<String> girlMessages = new ArrayList<>();
        jokerMessgaes.add("内个......在吗？");
        girlMessages.add("1");
        jokerMessgaes.add("其实...其实我喜欢你😄");
        girlMessages.add("没完没了了是吧？");
        jokerMessgaes.add("要怎样你才能接受我？😢");
        girlMessages.add("除非你告诉我你的银行卡密码");
        for(int i=0; i<jokerMessgaes.size(); i++){
            addMessageToChatHistory(jokerMessgaes.get(i), Gravity.END, 0); // 用户输入的文本向右靠齐
            addMessageToChatHistory(girlMessages.get(i), Gravity.START, 1); // 机器人回复的文本向左靠齐
        }
        addMessageToChatHistory("好好好，我这就给你发！", Gravity.END, 0);
//        Button button = findViewById(R.id.button_send);
//        button.setBackgroundResource(R.color.blue);
    }

    public void sendMessage(View view) {
        String jokerMessage = inputEditText.getText().toString().trim();
        if (!jokerMessage.isEmpty()) {

            SpannableString userMessage = new SpannableString(jokerMessage);
            userMessage.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_OPPOSITE), 0, jokerMessage.length(), 0);

            Thread thread = solveJokerMessage(jokerMessage);
            try {
                thread.join(); // 等待子线程执行完毕
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
//            solveJokerMessage(jokerMessage);
            SpannableString grilMessage = new SpannableString(result);
            grilMessage.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_NORMAL), 0, grilMessage.length(), 0);


            addMessageToChatHistory(userMessage, Gravity.END, 0); // 用户输入的文本向右靠齐
            addMessageToChatHistory(grilMessage, Gravity.START, 1); // 机器人回复的文本向左靠齐


            inputEditText.getText().clear();
        }
    }

    private void addMessageToChatHistory(CharSequence message, int gravity, int bubbleColor) {
        TextView textView = new TextView(this);
        textView.setText(message);
        textView.setPadding(16, 8, 16, 8); // 设置文本内边距，根据需要调整
        textView.setTextAppearance(android.R.style.TextAppearance_Material); // 使用默认文本样式
        textView.setBackground(getRoundedCornerDrawable(bubbleColor)); // 设置圆角背景
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.gravity = gravity; // 设置文本对齐方式
        params.topMargin = 8; // 上外边距，根据需要调整
        params.bottomMargin = 8; // 下外边距，根据需要调整
        chatHistoryLayout.addView(textView, params); // 添加到聊天记录中
    }

    private ShapeDrawable getRoundedCornerDrawable(int bubbleColor) {
        float[] radii = new float[]{16, 16, 16, 16, 16, 16, 16, 16}; // 圆角半径，根据需要调整
        ShapeDrawable shapeDrawable = new ShapeDrawable(new RoundRectShape(radii, null, null));
        if(bubbleColor == 0){
            shapeDrawable.getPaint().setColor(getResources().getColor(R.color.blue));
        }else {
            shapeDrawable.getPaint().setColor(getResources().getColor(R.color.pink));// 背景颜色，根据需要调整
        }
        return shapeDrawable;
    }

    public Thread solveJokerMessage(String message){
        String url = new String(ComparePassword.EncryptAlgorithmC(EncryptedURL, "rainb0w0w".getBytes()), StandardCharsets.UTF_8);
        String requestUrl = url + message;
        GetReponse getReponse = new GetReponse();

        Thread thread = new Thread(() -> {
            synchronized (ChatActivity.class) {
                try {
                    String resp = getReponse.get2url(requestUrl);
                    if(resp.contains("not be null") || resp.contains("connects error.")){
                        result = "死龟男，瞎发的什么？";
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
        return thread;
    }
}
