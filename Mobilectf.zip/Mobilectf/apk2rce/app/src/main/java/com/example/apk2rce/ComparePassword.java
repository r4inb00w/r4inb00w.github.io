package com.example.apk2rce;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class ComparePassword {
    public static boolean comparePassword(String password){
        try {
            String key = "eacaf076c1c913e2a995836c968f49d7";
            String EncryptedPass = EncryptAlgorithmA(EncryptAlgorithmB(password, key).getBytes());
            if(EncryptedPass.equals("N09hTHBqc1pBWE1tQVpUelFtRkxKQXBkbUNwcnlYTDNFYVFaaXdoL0daVT0=")){
                return true;
            }
        }catch (Exception e){

        }
        return false;
    }

    public static String EncryptAlgorithmA(byte[] bytes) {
        String Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        StringBuilder result = new StringBuilder();
        int paddingCount = (3 - bytes.length % 3) % 3;

        for (int i = 0; i < bytes.length; i += 3) {
            int chunk = ((bytes[i] & 0xFF) << 16) | ((i + 1 < bytes.length ? bytes[i + 1] & 0xFF : 0) << 8) | (i + 2 < bytes.length ? bytes[i + 2] & 0xFF : 0);
            for (int j = 0; j < 4; j++) {
                if (j <= bytes.length - i) {
                    int index = (chunk >> 6 * (3 - j)) & 0x3F;
                    result.append(Chars.charAt(index));
                } else {
                    result.append('=');
                }
            }
        }

        return result.toString();
    }

    public static String EncryptAlgorithmB(String input, String key) throws Exception {
        SecretKey secretKey = new SecretKeySpec(key.getBytes(), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(input.getBytes());
        return EncryptAlgorithmA(encryptedBytes);
    }

    public static byte[] EncryptAlgorithmC(byte[] plaintext, byte[] key) {
        byte[] encryptedText = new byte[plaintext.length];
        for (int i = 0; i < plaintext.length; i++) {
            encryptedText[i] = (byte) (plaintext[i] ^ key[i % key.length]);
        }
        return encryptedText;
    }

}
