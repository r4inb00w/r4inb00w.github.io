package com.example.apk2rce;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText inputEditText;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        inputEditText = findViewById(R.id.editTextPassword);
        submitButton = findViewById(R.id.buttonConfirm);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ComparePassword.comparePassword(inputEditText.getText().toString().trim())){
                    Intent intent = new Intent(MainActivity.this, CongratulationActivity.class);
                    startActivity(intent);
                }else {
                    Toast.makeText(getApplicationContext(), "密码错误，请重新输入", Toast.LENGTH_SHORT).show();
                    inputEditText.getText().clear();
                }
            }
        });
    }
}