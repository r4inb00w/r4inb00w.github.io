apk2rce目录下是App源码，大家可以自己编译着玩。其中ChatActivity中的EncryptedURL需要修改成自己的Java Web应用的url，且需要进行xor加密。

以下是构建需要的Java Web应用环境的命令：

首先构建docker容器：
docker build -t mobilectf:latest .
docker run -d -p 1012:1012 -it mobilectf:latest /bin/bash

接着运行docker exec -it <container_id> /bin/bash进入docker容器

然后在容器中执行/opt/server/run.sh来运行Java Web应用
